document.addEventListener('DOMContentLoaded', async function() {
    const toggleBtn = document.getElementById('toggleBtn');
    const viewLogsBtn = document.getElementById('viewLogsBtn');
    const clearLogsBtn = document.getElementById('clearLogsBtn');
    const statusDiv = document.getElementById('status');

    // Initialize state
    let isActive = false;
    
    try {
        const result = await chrome.storage.local.get(['keyloggerActive']);
        isActive = result.keyloggerActive || false;
        updateUI();
    } catch (err) {
        console.error("Storage error:", err);
    }

    // Toggle functionality with proper error handling
    toggleBtn.addEventListener('click', async () => {
        try {
            isActive = !isActive;
            await chrome.storage.local.set({ keyloggerActive: isActive });
            updateUI();
            
            const [tab] = await chrome.tabs.query({active: true, currentWindow: true});
            
            // Try communication with error fallback
            try {
                await chrome.tabs.sendMessage(tab.id, {
                    type: 'TOGGLE_LOGGING',
                    isActive: isActive
                });
            } catch (err) {
                console.log("Injecting content script...");
                await chrome.scripting.executeScript({
                    target: {tabId: tab.id},
                    files: ['content.js']
                });
                // Retry message after injection
                await chrome.tabs.sendMessage(tab.id, {
                    type: 'TOGGLE_LOGGING',
                    isActive: isActive
                });
            }
        } catch (err) {
            console.error("Toggle failed:", err);
            statusDiv.textContent = `Error: ${err.message}`;
        }
    });

    // View logs button
    viewLogsBtn.addEventListener('click', () => {
        chrome.tabs.create({url: 'http://localhost:3000/logs'});
    });

    // Clear logs button
    clearLogsBtn.addEventListener('click', async () => {
        try {
            await fetch('http://localhost:3000/clear-logs', {method: 'POST'});
            alert('Logs cleared successfully');
        } catch (err) {
            alert('Clear failed: ' + err.message);
        }
    });

    function updateUI() {
        if (isActive) {
            statusDiv.textContent = 'Status: ACTIVE';
            statusDiv.style.backgroundColor = '#4CAF50';
            toggleBtn.textContent = 'Stop Logging';
        } else {
            statusDiv.textContent = 'Status: Inactive';
            statusDiv.style.backgroundColor = '#f44336';
            toggleBtn.textContent = 'Start Logging';
        }
    }
});